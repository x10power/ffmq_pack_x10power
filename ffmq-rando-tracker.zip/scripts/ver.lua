print("Package Name:    Final Fantasy Mystic Quest Randomizer Item Tracker")
print("Package Author:  x10power, Mike Trethewey")
print("Package Version: 1.0.0.64")
